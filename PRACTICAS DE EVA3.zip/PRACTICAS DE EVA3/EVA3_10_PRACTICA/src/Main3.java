
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author meh
 */
public class Main3 {
      public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Ingresa el numero de tu calificacion de 6 a 10");
        int iNum = input.nextInt();
        
        System.out.println("Tu calificacion es " + Calificacion(iNum));
        
    }
    public static String Calificacion (int iNum){
String sCal = "";

 switch (iNum) {
     
     case 10: sCal = "A" ;break;
     case 9: sCal = "B" ;break;
     case 8: sCal = "C" ;break;
     case 7: sCal = "D" ;break;
     case 6: sCal = "F" ;break;    
 }

  return sCal ;
    
    }
}
