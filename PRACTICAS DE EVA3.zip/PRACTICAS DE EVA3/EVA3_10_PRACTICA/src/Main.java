
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jorge Gomez
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
    Scanner input = new Scanner(System.in);
        System.out.println("Ingresa El Numero Del Mes Que Deseas Saber");
        int iNum = input.nextInt();
        
        System.out.println("Mes: "+QueMes(iNum));
        
    }
    public static String  QueMes(int iNum){
String iMes = "";

 switch (iNum) {
     
     case 1: iMes = "Enero";
     break;
     case 2: iMes = "Febrero";
     break;
     
     case 3: iMes = "Marzo";
     break;
     case 4: iMes = "Abril";
     break;
     
     case 5: iMes = "Mayo";
     break;
     
     case 6: iMes = "Junio";
     break;
     
     case 7: iMes = "Julio";
     break;
    
     case 8: iMes = "Agosto";
     break;
     
     case 9: iMes = "Septiembre";
     break;
     
     case 10: iMes = "Octubre";
     break;
     
     case 11: iMes = "Noviembre";
     break;
     
     case 12: iMes = "Diciembre";
     break;
     
 }

  return iMes ;
    
    }
    
}
