
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jorge Gallegos 
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input=new Scanner (System.in);
        for (int i = 1; i <= 100; i++) {
            System.out.println(i);  
            }
        System.out.println("*********************************************");
        for (int i = 100; i >= 1; i--) {
            System.out.println(i);
        
        }
        int i=1;
     while((i <=100 )){
        System.out.print(i +" - ");
        i++;
     }
        System.out.println(""); 
     int j=100;
     while((j >=1 )){
        System.out.print(j +" - ");
        j--;
        }
    }}

   

