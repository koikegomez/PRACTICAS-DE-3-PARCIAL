/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Jorge Gomez
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //PARA USAR LA FUNCION -->LLAMADA A FUNCION
       // imprime ("Jorge");
       
        Main hObjeto = new Main();
        hObjeto.imprimeMensaje("Carlos");
        Math.random();
        
    }
    //Paradigmas de Programacion :
    //Programracion estructurada
    // PROGRAMACION MODULAR, ORIENTADA A OBJETOS,
    //ORIENTA A EVENTOS , LOGICA, FUNCIONAL
    
    //publico privado protegido default
    // Valor de retorno nombre de la funcion (argumentos)
    //(Cuerpo de la funcion)
     void imprimeMensaje (String mensaje){
        System.out.println("Hola " + mensaje);
     } 
}
